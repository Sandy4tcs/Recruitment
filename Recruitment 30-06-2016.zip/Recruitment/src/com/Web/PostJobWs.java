package com.Web;




import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;




@WebService()
@Entity
@Path("/submitdata")
public class PostJobWs {

    String query="";
    String query2="";
    @POST
    @Path("submit") 
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces("text/plain")
    @WebMethod(operationName = "submit")
	public void submitData(@FormParam("jobtitle") String jobtitle,
							@FormParam("location") String location,
							@FormParam("miles") String miles,
							@FormParam("salary") String salary,
							@FormParam("jobtype") String jobtype,
							@FormParam("jobtime") String jobtime,
							@FormParam("degree") String degree,
							@FormParam("degreeSubject") String degreeSubject,
							@FormParam("institution") String institution,
							@FormParam("jobexp") String jobexp,
							@FormParam("licence") String licence,
							@FormParam("carowner") String carowner,
							@FormParam("vacancy") int vacancy,
							@Context HttpServletResponse servletResponse) throws IOException
	{
    	SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
    	SimpleDateFormat formatdate=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		PreparedStatement st = null;
    	Connection connection=null;
		DBconnection database= new DBconnection();
		Date date= new Date();
		String currdate = format.format(date);
		String nowdate=formatdate.format(date);
		String action="CREATED";
		try {
			connection = database.getConnection();
			query= "INSERT INTO JOBPROFILES (JOBTITLE,LOCATION,MILES,SALARY,JOBTYPE,JOBTIME,DEGREE,SUBJECT,INSTITUTION,JOB_EXPERIENCE,DRIVING_LICENCE,CAR_OWNER,CREATION_DATE,VACANCY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			st=connection.prepareStatement(query);
			st.setString(1,jobtitle);
			st.setString(2, location);
			st.setString(3, miles);
			st.setString(4, salary);
			st.setString(5, jobtype);
			st.setString(6, jobtime);
			st.setString(7, degree);
			st.setString(8, degreeSubject);
			st.setString(9, institution);
			st.setString(10, jobexp);
			st.setString(11, licence);
			st.setString(12, carowner);
			st.setString(13, currdate);
			st.setInt(14, vacancy);
			st.executeUpdate();
			st.close();
			query2="INSERT INTO ALERTBOX (JOBNAME,TIME,JOBACTION) VALUES (?,?,?)";
			st=connection.prepareStatement(query2);
			st.setString(1, jobtitle);
			st.setString(2, nowdate);
			st.setString(3, action);
			st.executeUpdate();
			System.out.println(st.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
   	
	 }
   
	
	
}
