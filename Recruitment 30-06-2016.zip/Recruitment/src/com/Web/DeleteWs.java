package com.Web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@WebService()
@Entity
@Path("/delete")
public class DeleteWs {
	
	String query="";
	String query2="";
	String query3="";
	
	DBconnection database=new DBconnection();
	Connection connection=null;
	PreparedStatement st = null;
	@GET
	@Path("deletejob")
	@Produces("text/plain")
	@WebMethod(operationName = "deletejob")
	public void deleteJob(@QueryParam("id") String id)
	{
		SimpleDateFormat formatdate=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date= new Date();
		ResultSet rs = null;
		String nowdate=formatdate.format(date);
		String action="DELETED";
		String jobtitle="";
		try {
			connection = database.getConnection();
			query3="SELECT JOBTITLE FROM JOBPROFILES WHERE JOBID="+id;
			st=connection.prepareStatement(query3);
			rs=st.executeQuery();
			while (rs.next()) {
				jobtitle=rs.getString("JOBTITLE");
			}
			st.close();
			
			query="DELETE FROM JOBPROFILES where JOBID="+id;
			st=connection.prepareStatement(query);
			st.executeUpdate();
			st.close();
			query2="INSERT INTO ALERTBOX (JOBNAME,TIME,JOBACTION) VALUES (?,?,?)";
			st=connection.prepareStatement(query2);
			st.setString(1, jobtitle);
			st.setString(2, nowdate);
			st.setString(3, action);
			st.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	@GET
	@Path("deleteprofile")
	@Produces("text/plain")
	@WebMethod(operationName = "deleteprofile")
	public void deleteProfile(@QueryParam("id") String id)
	{
		try {
			connection = database.getConnection();
			query="DELETE FROM LOCALCANDIDATES where CID="+id;
			st=connection.prepareStatement(query);
			st.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

}
