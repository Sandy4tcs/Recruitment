package com.Web;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.beans.CandidateDetails;
import com.beans.JobProfile;
import com.google.gson.Gson;


@WebService()
@Entity
@Path("/searchcandidate")
public class SearchCandidateWs {
	
	String query1="";
	String query2="";
	String query3="";
	@GET
	@Path("searchlist")
	@Produces("text/plain")
	@WebMethod(operationName = "searchlist")
	public String getCandidateList(@QueryParam("jobid") String jobid)
	{
		double count=0;
		int profilecount=0;
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat formatdate=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		ArrayList<CandidateDetails> candidateList=new ArrayList<CandidateDetails>();
		JobProfile jd=new JobProfile();
		Date date= new Date();
		String nowdate=formatdate.format(date);
		DBconnection database=new DBconnection();
		Connection connection=null;
		ResultSet rs = null;
		String json="";
		PreparedStatement st = null;
		try {
			connection = database.getConnection();
			query1="SELECT * FROM JOBPROFILES WHERE JOBID=?";
			st=connection.prepareStatement(query1);
			st.setString(1,jobid);
			rs=st.executeQuery();
			
			while (rs.next()){
				jd.setJobid(rs.getString("JOBID"));
				//System.out.println(rs.getString("JOBID"));
				jd.setJobTitle(rs.getString("JOBTITLE"));
				//System.out.println(rs.getString("JOBTITLE"));
				jd.setLocation(rs.getString("LOCATION"));
				//System.out.println(rs.getString("LOCATION"));
				jd.setMiles(rs.getString("MILES"));
				//System.out.println(rs.getString("MILES"));
				jd.setSalary(rs.getString("SALARY"));
				//System.out.println(rs.getString("SALARY"));
				jd.setJobType(rs.getString("JOBTYPE"));
				//System.out.println(rs.getString("JOBTYPE"));
				jd.setJobTime(rs.getString("JOBTIME"));
				//System.out.println(rs.getString("JOBTIME"));
				jd.setDegree(rs.getString("DEGREE"));
				jd.setSubject(rs.getString("SUBJECT"));
				jd.setInstitution(rs.getString("INSTITUTION"));
				jd.setJobExp(rs.getString("JOB_EXPERIENCE"));
				jd.setDrivingLicence(rs.getString("DRIVING_LICENCE"));
				jd.setCarowner(rs.getString("CAR_OWNER"));
			}
			st.close();
			query2 = "SELECT CANDIDATE_ID,FNAME,LNAME,GENDER,ADDRESS,DEGREE,SUBJECT,UNIVERSITY,JOB_EXPERIENCE,PHONENO,SKILL1,SKILL2,SKILL,DRIVING_LICENCE,CAR_OWNER,MILES,EMAIL,APINAME,ADDED_ON FROM CANDIDATEPROFILES "
					+"WHERE (SKILL1 LIKE \'%"+ jd.getJobTitle().toUpperCase().trim().substring(0, 4) +"%\' AND ADDRESS like \'%"+ jd.getLocation().toUpperCase().trim() +"%\' AND MILES<="+jd.getMiles()
					+" AND JOB_EXPERIENCE>=\'"+ jd.getJobExp().toUpperCase() +"\' AND DEGREE LIKE \'%"+ jd.getDegree().toUpperCase()+"%\' AND SUBJECT LIKE \'%"+ jd.getSubject().toUpperCase() +"%\' AND UNIVERSITY LIKE \'%"+ jd.getInstitution().toUpperCase() +"%\')"
					+" OR (SKILL2 LIKE \'%"+ jd.getJobTitle().toUpperCase().trim().substring(0, 4) +"%\' AND ADDRESS like \'%"+ jd.getLocation().toUpperCase().trim() +"%\' AND MILES<="+jd.getMiles()
					+" AND JOB_EXPERIENCE>=\'"+ jd.getJobExp().toUpperCase() +"\' AND DEGREE LIKE \'%"+ jd.getDegree().toUpperCase()+"%\' AND SUBJECT LIKE \'%"+ jd.getSubject().toUpperCase() +"%\' AND UNIVERSITY LIKE \'%"+ jd.getInstitution().toUpperCase() +"%\')"
					+" OR (SKILL LIKE \'%"+ jd.getJobTitle().toUpperCase().trim().substring(0, 4) +"%\' AND ADDRESS like \'%"+ jd.getLocation().toUpperCase().trim() +"%\' AND MILES<="+jd.getMiles()
					+" AND JOB_EXPERIENCE>=\'"+ jd.getJobExp().toUpperCase() +"\' AND DEGREE LIKE \'%"+ jd.getDegree().toUpperCase()+"%\' AND SUBJECT LIKE \'%"+ jd.getSubject().toUpperCase() +"%\' AND UNIVERSITY LIKE \'%"+ jd.getInstitution().toUpperCase() +"%\')";			
			
//			if(jd.getDrivingLicence()!=null)
//			{
//				query2.concat(" AND DRIVING_LICENCE="+jd.getDrivingLicence());
//			}
//			if(jd.getCarowner()!=null)
//			{
//				query2.concat(" AND CAR_OWNER="+jd.getCarowner());
//			}
			
			
			st = connection.prepareStatement(query2);
			//System.out.println(st.toString());
			rs = st.executeQuery();
			
			while (rs.next()) {
				CandidateDetails cd=new CandidateDetails();
				++profilecount;
				cd.setCandidateId(rs.getString("CANDIDATE_ID"));
				cd.setFirstName(rs.getString("FNAME"));
				cd.setLastName(rs.getString("LNAME"));
//				cd.setGender(rs.getString("GENDER"));
				cd.setAddress(rs.getString("ADDRESS"));
//				cd.setDegree(rs.getString("DEGREE"));
//				cd.setSubject(rs.getString("SUBJECT"));
//				cd.setUniversity(rs.getString("UNIVERSITY"));
//				cd.setExperience(rs.getString("JOB_EXPERIENCE"));
				cd.setPhoneNo(rs.getString("PHONENO"));
//				cd.setSkill1(rs.getString("SKILL1"));
//				cd.setSkill2(rs.getString("SKILL2"));
//				cd.setSkill(rs.getString("SKILL"));
//				cd.setDrivinglicence(rs.getString("DRIVING_LICENCE"));
//				cd.setCarowner(rs.getString("CAR_OWNER"));
//				cd.setMiles(rs.getString("MILES"));
				cd.setEmail(rs.getString("EMAIL"));
				cd.setApiname(rs.getString("APINAME"));
				Date adddate= (Date) format.parse(rs.getString("ADDED_ON"));
				String currdate = format.format(date);
				Date curdate = format.parse(currdate);
				long diff=curdate.getTime()-adddate.getTime();
				long diffdays=diff/(24 * 60 * 60 * 1000);
				cd.setDate(diffdays+" days ago");
				if(jd.getMiles().equalsIgnoreCase(rs.getString("MILES")))
				{
					count=count+12.5;
					//System.out.println(1);
				}
				else
				{
					count=count+9;
					//System.out.println(2);
				}
				
				if(jd.getCarowner().equalsIgnoreCase(rs.getNString("CAR_OWNER")))
				{
					count=count+12.5;
				}
				else
				{
					count=count+9;
				}
				
				if(jd.getDrivingLicence().equalsIgnoreCase(rs.getString("DRIVING_LICENCE")))
				{
					count=count+12.5;
				}
				else
				{
					count=count+9;
				}
				
				if(jd.getLocation().equalsIgnoreCase(rs.getString("ADDRESS")))
				{
					count=count+12.5;
					//System.out.println(3);
				}
				else
				{
					count=count+9;
					//System.out.println(4);
				}
				if(jd.getDegree().equalsIgnoreCase(rs.getString("DEGREE")))
				{
					count=count+12.5;
					//System.out.println(5);
				}
				else
				{
					count=count+9;
					//System.out.println(6);
				}
				if(jd.getSubject().equalsIgnoreCase(rs.getString("SUBJECT")))
				{
					count=count+12.5;
					//System.out.println(7);
				}
				else
				{
					count=count+9;
					//System.out.println(8);
				}
				if(jd.getInstitution().equalsIgnoreCase(rs.getString("UNIVERSITY")))
				{
					count=count+12.5;
					//System.out.println(9);
				}
				else
				{
					count=count+9;
					//System.out.println(10);
				}
				if(jd.getJobExp().equalsIgnoreCase(rs.getString("JOB_EXPERIENCE")))
				{
					count=count+12.5;
					//System.out.println(11);
				}
				else
				{
					count=count+9;
					//System.out.println(12);
				}
				cd.setPercent(""+count+"%");
				candidateList.add(cd);
				json=new Gson().toJson(candidateList);
				count=0;
			}
			st.close();
			query3="INSERT INTO UPDATEBOX (JOBNAME,PROFILECOUNT,TIME) VALUES (?,?,?)";
			st=connection.prepareStatement(query3);
			st.setString(1, jd.getJobTitle());
			st.setLong(2, profilecount);
			st.setString(3, nowdate);
			st.executeUpdate();
			System.out.println(st.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return json;
	}

}
