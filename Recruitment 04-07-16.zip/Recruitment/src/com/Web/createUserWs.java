package com.Web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@WebService()
@Entity
@Path("/createprofile")
public class createUserWs {

	String query="";
    @POST
    @Path("create") 
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces("text/plain")
    @WebMethod(operationName = "create")
    public void setUserProfile(@FormParam("username") String username,@FormParam("password") String password)
    {
    	PreparedStatement st = null;
    	Connection connection=null;
		DBconnection database= new DBconnection();
		try {
			connection = database.getConnection();
			query="INSERT INTO USER (USERNAME,PASSWORD) VALUES(?,?)";
			st=connection.prepareStatement(query);
			st.setString(1,username);
			st.setString(2, password);
			st.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    }
}
