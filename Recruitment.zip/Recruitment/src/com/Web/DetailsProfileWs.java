package com.Web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.beans.CandidateDetails;
import com.google.gson.Gson;

@WebService()
@Entity
@Path("/details")
public class DetailsProfileWs {

	String query1="";
	@GET
	@Path("detailsprofile")
	@Produces("text/plain")
	@WebMethod(operationName = "detailsprofile")
	public String setLocalProfiles(@QueryParam("data") String key)
	{
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		ArrayList<CandidateDetails> list=new ArrayList<CandidateDetails>();
		DBconnection database=new DBconnection();
		Connection connection=null;
		ResultSet rs = null;
		CandidateDetails cd=null;
		PreparedStatement st = null;
		String json="";
		try {
			connection = database.getConnection();
			query1="SELECT * FROM CANDIDATEPROFILES WHERE CANDIDATE_ID=\'"+key+"\'";

			st=connection.prepareStatement(query1);
			rs=st.executeQuery();
			while (rs.next()) {
				cd=new CandidateDetails();
				cd.setFirstName(rs.getString("FNAME"));
				cd.setLastName(rs.getString("LNAME"));
//				cd.setGender(rs.getString("GENDER"));
				cd.setAddress(rs.getString("ADDRESS"));
				cd.setDegree(rs.getString("DEGREE"));
				cd.setSubject(rs.getString("SUBJECT"));
				cd.setUniversity(rs.getString("UNIVERSITY"));
				cd.setExperience(rs.getString("JOB_EXPERIENCE"));
				cd.setPhoneNo(rs.getString("PHONENO"));
				cd.setSkill1(rs.getString("SKILL1"));
				cd.setSkill2(rs.getString("SKILL2"));
				cd.setSkill(rs.getString("SKILL"));
				cd.setDrivinglicence(rs.getString("DRIVING_LICENCE"));
				cd.setCarowner(rs.getString("CAR_OWNER"));
				cd.setMiles(rs.getString("MILES"));
				cd.setEmail(rs.getString("EMAIL"));	
//				cd.setApiname(rs.getString("APINAME"));
//				Date adddate= (Date) format.parse(rs.getString("ADDED_ON"));
//				Date date= new Date();
//				String currdate = format.format(date);
//				Date curdate = format.parse(currdate);
//				long diff=curdate.getTime()-adddate.getTime();
//				long diffdays=diff/(24 * 60 * 60 * 1000);
//				cd.setDate(diffdays+" days ago");
				list.add(cd);
				json=new Gson().toJson(list);
			}
			st.close();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
		return json;
	}
}
