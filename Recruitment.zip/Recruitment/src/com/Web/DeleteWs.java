package com.Web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@WebService()
@Entity
@Path("/delete")
public class DeleteWs {
	
	String query="";
	DBconnection database=new DBconnection();
	Connection connection=null;
	PreparedStatement st = null;
	@GET
	@Path("deletejob")
	@Produces("text/plain")
	@WebMethod(operationName = "deletejob")
	public void deleteJob(@QueryParam("id") String id)
	{
		try {
			connection = database.getConnection();
			query="DELETE FROM JOBPROFILES where JOBID="+id;
			st=connection.prepareStatement(query);
			st.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	@GET
	@Path("deleteprofile")
	@Produces("text/plain")
	@WebMethod(operationName = "deleteprofile")
	public void deleteProfile(@QueryParam("id") String id)
	{
		try {
			connection = database.getConnection();
			query="DELETE FROM LOCALCANDIDATES where CID="+id;
			st=connection.prepareStatement(query);
			st.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

}
