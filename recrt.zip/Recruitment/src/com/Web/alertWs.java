package com.Web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.Entity;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.beans.alertJob;
import com.google.gson.Gson;

@WebService()
@Entity
@Path("/alertbox")
public class alertWs {

	String query="";
	@GET
	@Path("createjobs")
	@Produces("text/plain")
	@WebMethod(operationName = "createjobs")
	public String getjobAlerts()
	{
		String json="";
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		ArrayList<alertJob> alertslist=new ArrayList<alertJob>();
		DBconnection database=new DBconnection();
		Connection connection=null;
		ResultSet rs = null;
		PreparedStatement st = null;
		try {
			connection = database.getConnection();
			query="SELECT JOBNAME,TIME FROM ALERTBOX WHERE JOBACTION=\'CREATED\' ORDER BY ALERTID DESC";
			st=connection.prepareStatement(query);
			rs=st.executeQuery();
			while (rs.next()) {
				alertJob alertjob=new alertJob();
				alertjob.setJobName(rs.getString("JOBNAME"));
				
				Date adddate= (Date) format.parse(rs.getString("TIME"));
				Date date= new Date();
				String currdate = format.format(date);
				Date curdate = format.parse(currdate);
				long diff=curdate.getTime()-adddate.getTime();
				long diffdays=diff/(24 * 60 * 60 * 1000);
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffSeconds = diff / 1000 % 60;
				long diffHours = diff / (60 * 60 * 1000);
				if (diffSeconds<=119)
				{
					alertjob.setTime(diffSeconds+" Seconds ago");
				}
				if (diffMinutes>=1 && diffMinutes<=59)
				{
					if(diffMinutes==1)
					{
						alertjob.setTime(diffMinutes+" Minute ago");
					}
					else
					{
					alertjob.setTime(diffMinutes+" Minutes ago");
					}
				}
				if (diffHours>=1 && diffHours<=24)
				{
					if(diffHours==1)
					{
						alertjob.setTime(diffHours+" Hour ago");
					}
					else
					{
					alertjob.setTime(diffHours+" Hours ago");
					}
				}
				if (diffdays>=1)
				{
					if(diffdays==1)
					{
						alertjob.setTime(diffdays+" Day ago");
					}
					else
					{
						alertjob.setTime(diffdays+" Days ago");
					}
					
				}
				alertslist.add(alertjob);
				json=new Gson().toJson(alertslist);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return json;
	}
	
	String query2="";
	@GET
	@Path("deletejobs")
	@Produces("text/plain")
	@WebMethod(operationName = "deletejobs")
	public String deletejobAlerts()
	{
		String json="";
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		ArrayList<alertJob> alertslist=new ArrayList<alertJob>();
		DBconnection database=new DBconnection();
		Connection connection=null;
		ResultSet rs = null;
		PreparedStatement st = null;
		try {
			connection = database.getConnection();
			query="SELECT JOBNAME,TIME FROM ALERTBOX WHERE JOBACTION=\'DELETED\' ORDER BY ALERTID DESC";
			st=connection.prepareStatement(query);
			rs=st.executeQuery();
			while (rs.next()) {
				alertJob alertjob=new alertJob();
				alertjob.setJobName(rs.getString("JOBNAME"));
				
				Date adddate= (Date) format.parse(rs.getString("TIME"));
				Date date= new Date();
				String currdate = format.format(date);
				Date curdate = format.parse(currdate);
				long diff=curdate.getTime()-adddate.getTime();
				long diffdays=diff/(24 * 60 * 60 * 1000);
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffSeconds = diff / 1000 % 60;
				long diffHours = diff / (60 * 60 * 1000);
				if (diffSeconds<=59)
				{
					alertjob.setTime(diffSeconds+" Seconds ago");
				}
				if (diffMinutes>=1 && diffMinutes<=59)
				{
					if(diffMinutes==1)
					{
						alertjob.setTime(diffMinutes+" Minute ago");
					}
					else
					{
					alertjob.setTime(diffMinutes+" Minutes ago");
					}
				}
				if (diffHours>=1 && diffHours<=24)
				{
					if(diffHours==1)
					{
						alertjob.setTime(diffHours+" Hour ago");
					}
					else
					{
					alertjob.setTime(diffHours+" Hours ago");
					}
				}
				if (diffdays>=1)
				{
					if(diffdays==1)
					{
						alertjob.setTime(diffdays+" Day ago");
					}
					else
					{
						alertjob.setTime(diffdays+" Days ago");
					}
					
				}
				alertslist.add(alertjob);
				json=new Gson().toJson(alertslist);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.commit();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return json;
	}
	
	String query3="";
	@GET
	@Path("updatejobs")
	@Produces("text/plain")
	@WebMethod(operationName = "updatejobs")
	public String getUpdateJobs()
	{
		String json="";
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		ArrayList<alertJob> alertslist=new ArrayList<alertJob>();
		DBconnection database=new DBconnection();
		Connection connection=null;
		ResultSet rs = null;
		PreparedStatement st = null;
		try {
			connection = database.getConnection();
			query="SELECT JOBNAME,PROFILECOUNT,TIME FROM UPDATEBOX ORDER BY UID DESC";
			st=connection.prepareStatement(query);
			rs=st.executeQuery();
			while (rs.next()) {
				alertJob alertjob=new alertJob();
				alertjob.setJobName(rs.getString("JOBNAME"));
				alertjob.setCount(rs.getString("PROFILECOUNT"));
				Date adddate= (Date) format.parse(rs.getString("TIME"));
				Date date= new Date();
				String currdate = format.format(date);
				Date curdate = format.parse(currdate);
				long diff=curdate.getTime()-adddate.getTime();
				long diffdays=diff/(24 * 60 * 60 * 1000);
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffSeconds = diff / 1000 % 60;
				long diffHours = diff / (60 * 60 * 1000);
				if (diffSeconds<=59)
				{
					alertjob.setTime(diffSeconds+" Seconds ago");
				}
				if (diffMinutes>=1 && diffMinutes<=59)
				{
					if(diffMinutes==1)
					{
						alertjob.setTime(diffMinutes+" Minute ago");
					}
					else
					{
					alertjob.setTime(diffMinutes+" Minutes ago");
					}
				}
				if (diffHours>=1 && diffHours<=24)
				{
					if(diffHours==1)
					{
						alertjob.setTime(diffHours+" Hour ago");
					}
					else
					{
					alertjob.setTime(diffHours+" Hours ago");
					}
				}
				if (diffdays>=1)
				{
					if(diffdays==1)
					{
						alertjob.setTime(diffdays+" Day ago");
					}
					else
					{
						alertjob.setTime(diffdays+" Days ago");
					}
					
				}
				alertslist.add(alertjob);
				json=new Gson().toJson(alertslist);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return json;
	}
	
}
